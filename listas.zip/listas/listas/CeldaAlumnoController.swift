//
//  CeldaAlumnoController.swift
//  listas
//
//  Created by Alumno on 9/28/21.
//  Copyright © 2021 Alumno. All rights reserved.
//

import Foundation
import UIKit

class CeldaAlumnoController : UITableViewCell{
    @IBOutlet weak var lblAlumno: UILabel!
    @IBOutlet weak var lblPromedio: UILabel!
    @IBOutlet weak var lblMatricula: UILabel!
    
}
